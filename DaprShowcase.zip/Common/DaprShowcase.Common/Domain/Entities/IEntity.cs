﻿using System;

namespace DaprShowcase.Common.Domain.Entities
{
    public interface IEntity
    {
        Guid Id { get; }
    }
}
