﻿namespace DaprShowcase.Common.Application.Messages
{
    public interface IMessage
    {
        string Id { get; }
    }
}