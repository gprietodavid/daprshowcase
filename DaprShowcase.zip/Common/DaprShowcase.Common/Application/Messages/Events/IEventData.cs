﻿namespace DaprShowcase.Common.Application.Messages.Events
{
    public interface IEventData : IMessage
    {
    }
}