﻿using DaprShowcase.Common.Adapters.BlobStorage;

namespace DaprShowcase.Services.ZipWorker.Adapters
{
    public interface IDocumentBlobStorageAdapter : IBlobStorageAdapter
    {
    }
}