﻿using DaprShowcase.Common.Adapters.BlobStorage;

namespace DaprShowcase.Services.AvScanWorker.Adapters
{
    public interface IDocumentBlobStorageAdapter : IBlobStorageAdapter
    {
    }
}