﻿namespace DaprShowcase.Services.Orchestrator.Application.Messages
{
    public interface IMessage
    {
        string Id { get; }
    }
}