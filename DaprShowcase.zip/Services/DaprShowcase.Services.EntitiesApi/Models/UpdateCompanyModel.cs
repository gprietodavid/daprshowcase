﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DaprShowcase.Services.EntitiesApi.Models
{
    public class UpdateCompanyModel
    {
        public string Name { get; set; }
    }
}