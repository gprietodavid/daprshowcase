﻿using DaprShowcase.Common.Adapters.BlobStorage;

namespace DaprShowcase.Services.DocumentsApi.Adapters.DocumentBlobStorage
{
    public interface IDocumentBlobStorageAdapter : IBlobStorageAdapter
    {
    }
}