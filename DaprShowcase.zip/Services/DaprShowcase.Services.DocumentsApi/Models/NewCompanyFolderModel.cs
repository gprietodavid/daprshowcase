﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DaprShowcase.Services.DocumentsApi.Models
{
    public class NewCompanyFolderModel
    {
        public string CompanyId { get; set; }
        public string Name { get; set; }
    }
}